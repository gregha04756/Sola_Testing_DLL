#pragma once

#include "resource.h"

#define WM_APPDLGENDING WM_APP

